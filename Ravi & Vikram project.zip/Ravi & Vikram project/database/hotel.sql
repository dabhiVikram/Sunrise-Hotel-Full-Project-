-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Oct 01, 2024 at 05:28 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.0.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `hotel`
--

-- --------------------------------------------------------

--
-- Table structure for table `contact`
--

CREATE TABLE `contact` (
  `id` int(10) UNSIGNED NOT NULL,
  `fullname` varchar(100) DEFAULT NULL,
  `phoneno` int(10) DEFAULT NULL,
  `email` text DEFAULT NULL,
  `cdate` date DEFAULT NULL,
  `approval` varchar(12) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `contact`
--

INSERT INTO `contact` (`id`, `fullname`, `phoneno`, `email`, `cdate`, `approval`) VALUES
(2, 'ravi', 1234657980, 'KP23@GMAIL.COM', '2024-09-17', 'Allowed'),
(3, 'bilu', 2147483647, 'ra@gmail.com', '2024-09-17', 'Allowed'),
(4, 'dsfgsd', 2147483647, 'dfsdgfds@gmail.com', '2024-09-25', 'Allowed');

-- --------------------------------------------------------

--
-- Table structure for table `login`
--

CREATE TABLE `login` (
  `id` int(10) UNSIGNED NOT NULL,
  `usname` varchar(30) DEFAULT NULL,
  `pass` varchar(30) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `login`
--

INSERT INTO `login` (`id`, `usname`, `pass`) VALUES
(1, 'sunrise', 'sunrise123'),
(3, 'ravi', 'ravi123'),
(4, 'admin', '1234');

-- --------------------------------------------------------

--
-- Table structure for table `newsletterlog`
--

CREATE TABLE `newsletterlog` (
  `id` int(10) UNSIGNED NOT NULL,
  `title` varchar(52) DEFAULT NULL,
  `subject` varchar(100) DEFAULT NULL,
  `news` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `newsletterlog`
--

INSERT INTO `newsletterlog` (`id`, `title`, `subject`, `news`) VALUES
(1, 'abc', 'room', 'booking'),
(2, ' hotel issu', 'about hotel', 'sadvesvds'),
(3, '', '', ''),
(4, '', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `payment`
--

CREATE TABLE `payment` (
  `id` int(11) DEFAULT NULL,
  `title` varchar(5) DEFAULT NULL,
  `fname` varchar(30) DEFAULT NULL,
  `lname` varchar(30) DEFAULT NULL,
  `troom` varchar(30) DEFAULT NULL,
  `tbed` varchar(30) DEFAULT NULL,
  `nroom` int(11) DEFAULT NULL,
  `cin` date DEFAULT NULL,
  `cout` date DEFAULT NULL,
  `ttot` double(8,2) DEFAULT NULL,
  `fintot` double(8,2) DEFAULT NULL,
  `mepr` double(8,2) DEFAULT NULL,
  `meal` varchar(30) DEFAULT NULL,
  `btot` double(8,2) DEFAULT NULL,
  `noofdays` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `payment`
--

INSERT INTO `payment` (`id`, `title`, `fname`, `lname`, `troom`, `tbed`, `nroom`, `cin`, `cout`, `ttot`, `fintot`, `mepr`, `meal`, `btot`, `noofdays`) VALUES
(2, 'Dr.', 'saf', 'sd', 'Superior Room', 'Single', 1, '2024-09-05', '2024-09-07', 640.00, 659.20, 12.80, 'Breakfast', 6.40, 2),
(3, 'Miss.', 'ravi', 'parmaR', 'Superior Room', 'Single', 1, '2024-09-05', '2024-09-14', 2880.00, 2908.80, 0.00, 'Room only', 28.80, 9),
(4, 'Dr.', 'raj', 'ahir', 'Deluxe Room', 'Double', 1, '2024-09-12', '2024-09-14', 440.00, 448.80, 0.00, 'Room only', 8.80, 2),
(5, 'Dr.', 'cxsd', 'parmaR', 'Superior Room', 'Double', 1, '2024-09-12', '2024-09-28', 5120.00, 5222.40, 0.00, 'Room only', 102.40, 16);

-- --------------------------------------------------------

--
-- Table structure for table `room`
--

CREATE TABLE `room` (
  `id` int(10) UNSIGNED NOT NULL,
  `type` varchar(15) DEFAULT NULL,
  `bedding` varchar(10) DEFAULT NULL,
  `place` varchar(10) DEFAULT NULL,
  `cusid` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `room`
--

INSERT INTO `room` (`id`, `type`, `bedding`, `place`, `cusid`) VALUES
(1, 'Superior Room', 'Single', 'NotFree', 3),
(3, 'Superior Room', 'Triple', 'Free', NULL),
(4, 'Single Room', 'Quad', 'Free', NULL),
(5, 'Superior Room', 'Quad', 'Free', NULL),
(6, 'Deluxe Room', 'Single', 'Free', NULL),
(7, 'Deluxe Room', 'Double', 'NotFree', 4),
(8, 'Deluxe Room', 'Triple', 'Free', NULL),
(9, 'Deluxe Room', 'Quad', 'Free', NULL),
(10, 'Guest House', 'Single', 'Free', NULL),
(11, 'Guest House', 'Double', 'Free', NULL),
(12, 'Guest House', 'Quad', 'Free', NULL),
(13, 'Single Room', 'Single', 'Free', NULL),
(14, 'Single Room', 'Double', 'Free', NULL),
(15, 'Single Room', 'Triple', 'Free', NULL),
(16, 'Guest House', 'Triple', 'Free', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `roombook`
--

CREATE TABLE `roombook` (
  `id` int(10) UNSIGNED NOT NULL,
  `Title` varchar(5) DEFAULT NULL,
  `FName` text DEFAULT NULL,
  `LName` text DEFAULT NULL,
  `Email` varchar(50) DEFAULT NULL,
  `National` varchar(30) DEFAULT NULL,
  `Country` varchar(30) DEFAULT NULL,
  `Phone` text DEFAULT NULL,
  `TRoom` varchar(20) DEFAULT NULL,
  `Bed` varchar(10) DEFAULT NULL,
  `NRoom` varchar(2) DEFAULT NULL,
  `Meal` varchar(15) DEFAULT NULL,
  `cin` date DEFAULT NULL,
  `cout` date DEFAULT NULL,
  `stat` varchar(15) DEFAULT NULL,
  `nodays` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `roombook`
--

INSERT INTO `roombook` (`id`, `Title`, `FName`, `LName`, `Email`, `National`, `Country`, `Phone`, `TRoom`, `Bed`, `NRoom`, `Meal`, `cin`, `cout`, `stat`, `nodays`) VALUES
(4, 'Dr.', 'raj', 'ahir', 'abc@gmail.com', 'Indian', 'Bangladesh', '9654875252', 'Deluxe Room', 'Double', '1', 'Room only', '2024-09-12', '2024-09-14', 'Conform', 2),
(6, 'Dr.', 'meet', 'patel', 'patel@gmail.com', 'Indian', 'Angola', '6398524175', 'Guest House', 'Triple', '3', 'Breakfast', '2024-09-20', '2024-09-28', 'Not Conform', 8),
(7, 'Mr.', 'uday', 'ram', 'ram@gmail.com', 'Indian', 'Bangladesh', '1254785269', 'Guest House', 'Single', '1', 'Room only', '2024-12-31', '2024-06-29', 'Not Conform', -185),
(8, 'Dr.', 'yagnik', 'patel', 'y@gmail.com', 'Indian', 'Hong Kong', '65555646541', 'Deluxe Room', 'Double', '3', 'Breakfast', '2024-09-13', '2024-09-26', 'Not Conform', 13),
(9, 'Dr.', 'rakesh', 'meta', 'meta1@gmail.com', 'Sri Lankan', 'Albania', '9654875252', 'Superior Room', 'Single', '1', 'Room only', '2024-12-01', '2024-12-14', 'Not Conform', 13),
(10, 'Mr.', 'roname', 'metqa', 'ascsa@gmail.com', 'Indian', 'Afghanistan', '9537624112', 'Deluxe Room', 'Double', '3', 'Breakfast', '2024-09-26', '2024-09-28', 'Not Conform', 2),
(11, 'Mrs.', '2wq3ged', 'gd', 'Jeelranparariya82@gmail.com', 'Sri Lankan', 'Austria', 'gjgf', 'Superior Room', 'Double', '3', 'Breakfast', '2024-09-25', '2024-09-25', 'Not Conform', 0),
(12, 'Prof.', 'rajhsdvvs', 'sasa', 'e@gmnail.com', 'Indian', 'Belarus', '2354789654', 'Deluxe Room', 'Double', '3', 'Breakfast', '2024-12-10', '2024-12-10', 'Not Conform', 0),
(13, 'Mr.', 'sdds', 'aafs', 'dfds@gmail.com', 'Indian', 'Bahrain', '9875421425', 'Deluxe Room', 'Triple', '3', 'Breakfast', '2024-04-10', '2024-10-10', 'Not Conform', 183),
(14, 'Mrs.', 'x', 'cof', 'cu@gmail.com', 'Sri Lankan', 'Bahamas', '6524578987', 'Deluxe Room', 'Double', '1', 'Breakfast', '2024-07-10', '2024-10-10', 'Not Conform', 92),
(15, 'Dr.', 'meta', 'saf', 'meta@gmail.com', 'Sri Lankan', 'Anguilla', '1257895474', 'Guest House', 'Double', '3', 'Breakfast', '2024-12-12', '2024-12-01', 'Not Conform', -11),
(16, 'Dr.', 'king', 'john', 'king@gmail.com', 'Non Indian  ', 'Uganda', '9548789652', 'Single Room', 'Triple', '2', 'Breakfast', '2024-09-26', '2024-09-28', 'Not Conform', 2),
(17, 'Dr.', 'ravi1553', 'parmaR', 'dsfsdfds@gmail.com', 'Indian', 'Aruba', '96548752544', 'Superior Room', 'Single', '1', 'Room only', '2024-09-25', '2024-09-27', 'Not Conform', 2),
(18, 'Dr.', 'yagnikdss', 'patelas', 'vggdhruviii@gmail.com', 'Indian', 'Algeria', '9537624145', 'Guest House', 'Double', '2', 'Breakfast', '2024-09-24', '2024-09-28', 'Not Conform', 4),
(19, 'Dr.', 'safss', 'ramfs', 'dfdsssd@gmail.com', 'Indian', 'Algeria', '95376241454', 'Deluxe Room', 'Single', '2', 'Room only', '2024-09-24', '2024-09-26', 'Not Conform', 2),
(20, 'Dr.', 'ketan', 'sir', 'k@gmail.com', 'Sri Lankan', 'Bahamas', '4578965421', 'Superior Room', 'Triple', '3', 'Breakfast', '2024-09-26', '2024-09-28', 'Not Conform', 2);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `contact`
--
ALTER TABLE `contact`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `login`
--
ALTER TABLE `login`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `newsletterlog`
--
ALTER TABLE `newsletterlog`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `room`
--
ALTER TABLE `room`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `roombook`
--
ALTER TABLE `roombook`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `contact`
--
ALTER TABLE `contact`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `login`
--
ALTER TABLE `login`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `newsletterlog`
--
ALTER TABLE `newsletterlog`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `room`
--
ALTER TABLE `room`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT for table `roombook`
--
ALTER TABLE `roombook`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
